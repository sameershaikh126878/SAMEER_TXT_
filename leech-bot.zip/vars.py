API_ID = 12345678
API_HASH = "your_api_hash"
BOT_TOKEN = "your_bot_token"
CHANNEL_ID = -1001234567890  # your Telegram channel ID
