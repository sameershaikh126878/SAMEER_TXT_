def progress_bar(current, total):
    return f"{(current/total)*100:.2f}%"
